// <summary> This class is for Java MCQ set
// <summary> It fetches values from the CSV file for Java and Displays questions one by one

package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Java {
    int total;
    String javaset = "Java b.csv ";   //File name
    File javacsv = new File (javaset);
    int constant = 0;

    //displays questions and alternatives
    public int selectAlt() {
        /*displays questions and alternatives
         * and checks if answers are correct*/

        try{
            Scanner scanz = new Scanner(javacsv);
                while (scanz.hasNext()) {
                    String data = scanz.nextLine();
                    String[] split = data.split(",");
                    System.out.println();
                    System.out.println(split[0]);
                    System.out.println(split[1]);
                    System.out.println(split[2]);
                    System.out.println(split[3]);
                    System.out.println(split[4]);
                    int answer = Integer.parseInt(split[5]);

                    //Checking Answers
                     Options a = new Options();
                        int javaAlt = a.option();

                            if (javaAlt == answer) {
                                System.out.println("Correct!");
                                System.out.println();
                                constant++;   // increments after each correct answer
                                total++;
                            }

                            else {
                                System.out.println("Wrong! " + split[answer]+ " is the correct answer.");
                                System.out.println();
                                total++;
                            }
            }
            scanz.close();
        }
                catch (FileNotFoundException e) {
                    e.printStackTrace();
        }
        return constant;
    }
}
