// <summary> This class is for Control Structure MCQ set
// <summary> It fetches values from the CSV file for Control Structure and Displays questions one by one
// <returns>

package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ContrlStrc {

    int total;
    String cntrlset = "Control.csv "; //File Name
    File cntrlcsv = new File(cntrlset);
    int constant = 0;

    /*displays questions and alternatives
    * and checks if answers are correct*/
    public int chooseAlt() {
        try {
            Scanner scans = new Scanner(cntrlcsv);
            while (scans.hasNext()) {
                String data = scans.nextLine();
                String[] split = data.split(",");
                System.out.println();
                System.out.println(split[0]);
                System.out.println(split[1]);
                System.out.println(split[2]);
                System.out.println(split[3]);
                System.out.println(split[4]);
                int answer = Integer.parseInt(split[5]);

                //Checking Answers
                Options a = new Options();
                    int csAlt = a.option();

                        if (csAlt == answer) {
                            System.out.println("Correct!");
                            System.out.println();
                            constant++; // increments after each correct answer
                            total++;
                        }

                        else {
                            System.out.println("Wrong! " + split[answer] + " is the correct answer.");
                            System.out.println();
                            total++;
                        }
            }
            scans.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return constant;
    }
}