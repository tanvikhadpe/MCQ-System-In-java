package com.company;

public class Main {

    public static void main(String[] args) {
        Name put = new Name();  //Prompt user for name
        String student = put.askname();    //User name
        ChooseSet load = new ChooseSet();   //Prompt user for selecting set
        int file = load.setselect();  //Loading MCQ set

        //Java
        if (file == 1) {
            Java mcq = new Java();

            //gets total correct/ incorrect answers from respective class
            int correctAns= mcq.selectAlt();
            int finalTotal = mcq.total;
            int wrongAns = finalTotal-correctAns;
            int percent = (correctAns * 100) / finalTotal;
            System.out.println(student + " ,you got  " + correctAns + " questions correct and , " +  wrongAns+ " questions wrong. Your grand total is " + finalTotal);
            System.out.println("Your percentage for this test is "+percent + "%");
        }

        //Control Structures
        else if (file == 2) {
            ContrlStrc mcq = new ContrlStrc();

            //gets total correct/ incorrect answers from respective class
            int correctAns =  mcq.chooseAlt();
            int finalTotal = mcq.total;
            int wrongAns = finalTotal;
            int percent = (correctAns * 100) / finalTotal;
            System.out.println(student + ", you  got  " + correctAns + " questions correct and " +  wrongAns + " questions wrong. Your grand total is " + finalTotal);
            System.out.println("Your percentage for this test is  "+percent);
        }
    }
}
