//<summary> This class is for prompting the user to choose set
//<returns> Set id/ Number (1/2) entered by the user
package com.company;

import java.util.Scanner;

public class ChooseSet {
    int setId;

    public int setselect() {
/* This method is used for selecting the set of MCQ
    *It returns the input entered by the user (1/2) */
        System.out.println("Choose Your Multiple Choice Question Set. ");
        System.out.println("Enter 1 or 2");
        System.out.println("\n1- Java Basics");
        System.out.println("2- Control Structures");

        Scanner input = new Scanner(System.in);

        setId = input.nextInt();

            if (setId != 1 && setId != 2) {
                System.out.println("Please enter 1 or 2");  //Validation
                setselect();
            }

        return setId; // returns the input or the set selected by the user
    }
}



