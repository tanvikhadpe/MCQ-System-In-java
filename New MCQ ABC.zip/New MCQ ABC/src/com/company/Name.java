//<summary> This class prompts the user for names
//<returns> User's Name

package com.company;
import java.util.Scanner;

public class Name {

    String username;
/* This method asks users for their name
* and scans and stores it for displaying final results */

        public  String askname() {
                System.out.println("Enter Your Name"); //Prompt for name
                Scanner f = new Scanner(System.in);
                username = f.nextLine();
                System.out.println();

        return username; // saves name for displaying during final result
    }
}
